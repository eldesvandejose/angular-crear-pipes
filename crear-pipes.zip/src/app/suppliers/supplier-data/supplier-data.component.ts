import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'a02-supplier-data',
  templateUrl: './supplier-data.component.html',
  styleUrls: ['./supplier-data.component.css']
})
export class SupplierDataComponent implements OnInit {

  identifier: any;

  constructor(private customer: ActivatedRoute) {}

  ngOnInit() {
    this.identifier = this.customer.snapshot.params['id'];
  }
}
