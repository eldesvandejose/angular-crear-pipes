import { SmartTruncatePipe } from './smart-truncate.pipe';

describe('SmartTruncatePipe', () => {
  it('create an instance', () => {
    const pipe = new SmartTruncatePipe();
    expect(pipe).toBeTruthy();
  });
});
