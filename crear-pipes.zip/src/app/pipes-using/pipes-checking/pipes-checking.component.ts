import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-pipes-checking',
  templateUrl: './pipes-checking.component.html',
  styleUrls: ['./pipes-checking.component.css']
})

export class PipesCheckingComponent implements OnInit {
  cadenaParaRecortar = 'Esto es un literal demasiado largo, que queremos recortar a un máximo de 30 caracteres.';
  constructor() { }
  ngOnInit() {
  }
}
