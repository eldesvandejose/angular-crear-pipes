import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PipesCheckingComponent } from './pipes-checking/pipes-checking.component';
import { SmartTruncatePipe } from '../pipes/smart-truncate.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PipesCheckingComponent, SmartTruncatePipe],
  exports: [PipesCheckingComponent]
})
export class PipesUsingModule { }
